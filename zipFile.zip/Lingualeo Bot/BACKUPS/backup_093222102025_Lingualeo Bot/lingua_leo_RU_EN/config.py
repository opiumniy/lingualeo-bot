# Вставь сюда свои куки из curl-запроса (-b)
# Это строка вида "_ym_uid=...; userid=...;"
COOKIES_STR = "_ym_uid=1731927216910223507; _ym_d=1758474485; tmr_lvid=31559846206384e457309e14d672a9aa; tmr_lvidTS=1731927212432; remember=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjExMzg5NzE1LCJleHAiOjE3NjY1MDk3MDIsInR5cCI6ImEifQ.LcaJVzj-jjDw_A2NQtb0CskdghqlPlOekLYFywq1g1Y; userid=11389715; _ym_isad=1"

# Вставь сюда свой User-Agent из curl-запроса
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"

# ID пользователя из куки
USER_ID = "11389715"